const KEY_PRODUCTS = "mk_demo_products_v1";
const KEY_CART = "mk_demo_cart_v1";
const KEY_ORDERS = "mk_demo_orders_v1";
const DELIVERY = 80;
const seedProducts = [
 {id:"p1",name:"লেডিস হ্যান্ডব্যাগ",price:850,oldPrice:1200,category:"নারী ব্যাগ",description:"দৈনন্দিন ব্যবহারের জন্য স্টাইলিশ ব্যাগ।",image:""},
 {id:"p2",name:"ফ্লোরাল হিজাব",price:350,oldPrice:420,category:"পোশাক",description:"আরামদায়ক কাপড় ও সুন্দর নকশা।",image:""},
 {id:"p3",name:"জুয়েলারি সেট",price:280,oldPrice:380,category:"অ্যাক্সেসরিজ",description:"উপহার বা অনুষ্ঠানের জন্য মানানসই।",image:""},
 {id:"p4",name:"ডেকোরেটিভ প্ল্যান্ট পট",price:490,oldPrice:590,category:"ঘর সাজানো",description:"ঘরের সৌন্দর্য বাড়াতে ছোট্ট সংযোজন।",image:""}
];
let products = read(KEY_PRODUCTS, seedProducts);
let cart = read(KEY_CART, []);
let orders = read(KEY_ORDERS, []);
let category = "সব";
let currentView = "shop";
const $ = s => document.querySelector(s);
const money = n => "৳" + Number(n||0).toLocaleString("bn-BD");
const escapeHTML = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function read(key, fallback){try{const v=localStorage.getItem(key);return v?JSON.parse(v):JSON.parse(JSON.stringify(fallback))}catch{return JSON.parse(JSON.stringify(fallback))}}
function save(){localStorage.setItem(KEY_PRODUCTS,JSON.stringify(products));localStorage.setItem(KEY_CART,JSON.stringify(cart));localStorage.setItem(KEY_ORDERS,JSON.stringify(orders))}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2400)}
function imageHTML(p, cls=""){return p.image?`<img class="${cls}" src="${escapeHTML(p.image)}" alt="${escapeHTML(p.name)}" onerror="this.style.display='none'">`:`<span class="placeholder-art" aria-hidden="true">❀</span>`}
function switchView(view){currentView=view;document.querySelectorAll(".view").forEach(el=>el.classList.add("hidden"));const el=$("#"+view+"View");if(el)el.classList.remove("hidden");document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view===view));if(view==="cart")renderCart();if(view==="admin")renderAdmin();if(view==="shop")renderShop();window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
document.querySelectorAll("[data-back]").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.back)));
$("#browseBtn").addEventListener("click",()=>$("#productGrid").scrollIntoView({behavior:"smooth"}));
$("#searchBtn").addEventListener("click",renderShop);
$("#searchInput").addEventListener("input",renderShop);
function renderShop(){
 const query=$("#searchInput").value.trim().toLowerCase();
 const cats=["সব",...new Set(products.map(p=>p.category||"অন্যান্য"))];
 $("#categoryRow").innerHTML=cats.map(c=>`<button class="category ${c===category?'active':''}" data-cat="${escapeHTML(c)}">${escapeHTML(c)}</button>`).join("");
 document.querySelectorAll("[data-cat]").forEach(b=>b.addEventListener("click",()=>{category=b.dataset.cat;renderShop()}));
 const filtered=products.filter(p=>(category==="সব"||p.category===category)&&(`${p.name} ${p.description} ${p.category}`.toLowerCase().includes(query)));
 $("#productTotal").textContent=`${filtered.length}টি পণ্য`;
 $("#emptyProducts").classList.toggle("hidden",filtered.length!==0);
 $("#productGrid").innerHTML=filtered.map(p=>`<article class="product-card"><div class="product-image">${imageHTML(p)}</div><div class="product-info"><h3>${escapeHTML(p.name)}</h3><p class="description">${escapeHTML(p.description||"")}</p><span class="price">${money(p.price)}</span>${p.oldPrice?`<span class="old-price">${money(p.oldPrice)}</span>`:""}<div class="product-actions"><button class="add-btn" data-add="${p.id}">কার্টে যোগ করুন</button><button class="details-btn" data-detail="${p.id}">বিবরণ</button></div></div></article>`).join("");
 document.querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>addToCart(b.dataset.add)));
 document.querySelectorAll("[data-detail]").forEach(b=>b.addEventListener("click",()=>{const p=products.find(x=>x.id===b.dataset.detail);if(p)alert(`${p.name}\nমূল্য: ${money(p.price)}\n\n${p.description||""}`)}));
}
function addToCart(id){const p=products.find(x=>x.id===id);if(!p)return;const found=cart.find(x=>x.id===id);if(found)found.qty++;else cart.push({id,qty:1});save();updateCartCount();toast("পণ্যটি কার্টে যোগ হয়েছে");}
function updateCartCount(){$("#cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0)}
function renderCart(){
 cart=cart.filter(x=>products.some(p=>p.id===x.id));
 const host=$("#cartItems");
 if(!cart.length){host.innerHTML='<p class="empty">আপনার কার্ট খালি। শপ থেকে পণ্য যোগ করুন।</p>';$("#subtotal").textContent=money(0);$("#grandTotal").textContent=money(0);$("#checkoutBtn").disabled=true;return}
 $("#checkoutBtn").disabled=false;
 host.innerHTML=cart.map(item=>{const p=products.find(x=>x.id===item.id);return `<div class="cart-row"><div class="cart-thumb">${imageHTML(p)}</div><div class="cart-row-info"><b>${escapeHTML(p.name)}</b><span class="price">${money(p.price)}</span><div class="quantity"><button data-minus="${p.id}">−</button><span>${item.qty}</span><button data-plus="${p.id}">+</button></div></div><button class="remove-btn" data-remove="${p.id}">বাদ দিন</button></div>`}).join("");
 const subtotal=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
 $("#subtotal").textContent=money(subtotal);$("#grandTotal").textContent=money(subtotal+DELIVERY);
 document.querySelectorAll("[data-minus]").forEach(b=>b.onclick=()=>changeQty(b.dataset.minus,-1));
 document.querySelectorAll("[data-plus]").forEach(b=>b.onclick=()=>changeQty(b.dataset.plus,1));
 document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{cart=cart.filter(x=>x.id!==b.dataset.remove);save();renderCart();updateCartCount()});
}
function changeQty(id,delta){const item=cart.find(x=>x.id===id);if(item)item.qty+=delta;cart=cart.filter(x=>x.qty>0);save();renderCart();updateCartCount()}
$("#checkoutBtn").addEventListener("click",()=>{if(!cart.length)return;switchView("checkout")});
$("#checkoutForm").addEventListener("submit",e=>{
 e.preventDefault();if(!cart.length){toast("কার্টে পণ্য যোগ করুন");return}
 const data=Object.fromEntries(new FormData(e.currentTarget).entries());
 const items=cart.map(x=>{const p=products.find(y=>y.id===x.id);return {id:p.id,name:p.name,price:p.price,qty:x.qty}});
 const subtotal=items.reduce((s,x)=>s+x.price*x.qty,0);
 const order={id:"MK"+Date.now().toString().slice(-7),...data,items,subtotal,total:subtotal+DELIVERY,delivery:DELIVERY,status:"নতুন অর্ডার",payment:"ক্যাশ অন ডেলিভারি",date:new Date().toLocaleString("bn-BD")};
 orders.unshift(order);cart=[];save();updateCartCount();e.currentTarget.reset();switchView("orders");$("#trackingResults").innerHTML=orderCard(order);toast("ডেমো অর্ডার তৈরি হয়েছে: "+order.id);
});
function orderCard(o){return `<div class="panel tracking-card"><b>অর্ডার আইডি: ${escapeHTML(o.id)}</b><p>নাম: ${escapeHTML(o.customer)} · মোবাইল: ${escapeHTML(o.phone)}</p><p>ঠিকানা: ${escapeHTML(o.address)}</p><p>অর্ডারের অবস্থা: <span class="status">${escapeHTML(o.status)}</span></p><p>মোট: <b>${money(o.total)}</b> · ${escapeHTML(o.payment)}</p><small class="muted">${escapeHTML(o.date)}</small></div>`}
$("#trackForm").addEventListener("submit",e=>{e.preventDefault();const q=new FormData(e.currentTarget).get("query").trim().toLowerCase();const found=orders.filter(o=>o.id.toLowerCase()===q||o.phone.toLowerCase()===q);$("#trackingResults").innerHTML=found.length?found.map(orderCard).join(""):'<div class="panel tracking-card">এই ডেমো ব্রাউজারে কোনো অর্ডার পাওয়া যায়নি।</div>'});
function renderAdmin(){
 $("#statProducts").textContent=products.length;$("#statOrders").textContent=orders.length;$("#statNew").textContent=orders.filter(o=>o.status==="নতুন অর্ডার").length;
 $("#adminProducts").innerHTML=products.map(p=>`<div class="admin-item"><div><b>${escapeHTML(p.name)}</b><small>${money(p.price)} · ${escapeHTML(p.category||"অন্যান্য")}</small></div><div><button data-edit="${p.id}">এডিট</button><button data-delete="${p.id}">মুছুন</button></div></div>`).join("")||'<p class="muted">এখনো কোনো পণ্য নেই।</p>';
 document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>editProduct(b.dataset.edit));
 document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{if(confirm("এই পণ্যটি মুছে ফেলবেন?")){products=products.filter(p=>p.id!==b.dataset.delete);cart=cart.filter(x=>x.id!==b.dataset.delete);save();renderAdmin();updateCartCount();toast("পণ্য মুছে ফেলা হয়েছে")}});
 $("#adminOrders").innerHTML=orders.length?`<table class="order-table"><thead><tr><th>অর্ডার</th><th>কাস্টমার</th><th>মোট</th><th>অবস্থা</th><th>আপডেট</th></tr></thead><tbody>${orders.map(o=>`<tr><td>${escapeHTML(o.id)}<br><small>${escapeHTML(o.date)}</small></td><td>${escapeHTML(o.customer)}<br>${escapeHTML(o.phone)}</td><td>${money(o.total)}</td><td><span class="status">${escapeHTML(o.status)}</span></td><td><select class="status-select" data-status="${o.id}">${["নতুন অর্ডার","নিশ্চিত","প্যাকিং","পথে আছে","ডেলিভারি সম্পন্ন","বাতিল"].map(s=>`<option ${o.status===s?"selected":""}>${s}</option>`).join("")}</select></td></tr>`).join("")}</tbody></table>`:'<p class="muted">এখনো কোনো অর্ডার নেই।</p>';
 document.querySelectorAll("[data-status]").forEach(sel=>sel.onchange=()=>{const o=orders.find(x=>x.id===sel.dataset.status);if(o){o.status=sel.value;save();renderAdmin();toast("অর্ডারের অবস্থা আপডেট হয়েছে")}});
}
function editProduct(id){const p=products.find(x=>x.id===id);if(!p)return;const f=$("#productForm");Object.entries(p).forEach(([k,v])=>{if(f.elements[k])f.elements[k].value=v});$("#productFormTitle").textContent="পণ্য সম্পাদনা করুন";f.scrollIntoView({behavior:"smooth",block:"start"})}
function clearProductForm(){$("#productForm").reset();$("#productForm").elements.id.value="";$("#productFormTitle").textContent="নতুন পণ্য যোগ করুন"}
$("#cancelEdit").addEventListener("click",clearProductForm);
$("#productForm").addEventListener("submit",e=>{
 e.preventDefault();const f=e.currentTarget;const d=Object.fromEntries(new FormData(f).entries());const p={id:d.id||"p"+Date.now(),name:d.name.trim(),price:Number(d.price),oldPrice:Number(d.oldPrice)||0,category:d.category.trim()||"অন্যান্য",image:d.image.trim(),description:d.description.trim()};
 if(d.id){products=products.map(x=>x.id===d.id?p:x);toast("পণ্যের তথ্য আপডেট হয়েছে")}else{products.unshift(p);toast("নতুন পণ্য যোগ হয়েছে")}
 save();clearProductForm();renderAdmin();renderShop();
});
$("#resetDemo").addEventListener("click",()=>{if(confirm("সব ডেমো অর্ডার/পরিবর্তন মুছে নমুনা ডেটা ফিরিয়ে আনবেন?")){products=JSON.parse(JSON.stringify(seedProducts));cart=[];orders=[];save();clearProductForm();renderAdmin();renderShop();updateCartCount();toast("ডেমো ডেটা রিসেট হয়েছে")}});
$("#year").textContent=new Date().getFullYear();renderShop();renderCart();updateCartCount();
