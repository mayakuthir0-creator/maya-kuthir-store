MAYA KUTHIR WEBSITE - STARTER DEMO
=================================

Files:
- index.html : page structure
- style.css  : responsive design
- app.js     : demo product, cart, COD order, order tracking and admin interactions

IMPORTANT LIMITATIONS:
This is a front-end prototype. Data is saved only in the same browser/device using localStorage.
It is NOT a live multi-customer shop, and the demo admin panel has NO secure login.
Do not use it to collect real customer details or take real orders until a backend and secure admin authentication are configured.

How to preview on mobile:
1. Extract the ZIP on your phone.
2. Open index.html in a code editor or HTML preview app that can open local files.
3. For publishing, upload these three files to a static host such as GitHub Pages or Netlify.
4. Static hosting alone does not make admin/order data shared between customers.

Before real launch:
- Connect Firebase or another backend database.
- Configure admin authentication and database security rules.
- Save orders securely server-side and test order notifications.
- Add real product photos and verify delivery charges/policies.
